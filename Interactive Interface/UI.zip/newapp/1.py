with open("a.txt",'w') as fb:
    fb.write("你好我是小白")


