# coding:utf-8
from django.shortcuts import render
from django.http import HttpResponse
import os

def index(request):
    #os.system("python3 1.py")
    return render(request, 'index.html')

def answer(request):
    question = request.GET['question']
    with open("text.txt",'w') as ft1:
        ft1.write(question)
        with open("judge.txt",'w') as fj1:
            fj1.write("0")
    while True:
        with open("judge.txt",'r') as fj2:
            line = fj2.readline()
            if line == "1":
                with open("text.txt",'r') as ft2:
                    answer = ft2.read()
                    break
    return HttpResponse(answer)
# Create your views here.
